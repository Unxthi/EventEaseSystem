﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EventEasy.Migrations
{
    /// <inheritdoc />
    public partial class EventMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Events",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),  
                    EventName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    EventDescription = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    EventDate = table.Column<DateTime>(type: "datetime2", maxLength: 100, nullable: false),
                    VenueId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    VenuePrice = table.Column<decimal>(type: "decimal(38,2)", precision: 38, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Events", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Events");
        }
    }
}
