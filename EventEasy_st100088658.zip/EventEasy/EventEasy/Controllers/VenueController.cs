﻿using EventEasy.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Client;

namespace EventEasy.Controllers
{
    public class VenueController : Controller
    {
        public VenueController(ApplicationDbContext context)
        {
            Context = context;
        }

        public ApplicationDbContext Context { get; }

        public IActionResult Index()
        {
            var venue = Context.Venue.ToList();
      
            return View(venue);
        }

        public IActionResult Create()
        {
            return View();
        }
    }
}
