﻿using EventEasy.Models;
using EventEasy.Services;
using Microsoft.AspNetCore.Mvc;

public class EventController : Controller
{
    public EventController(ApplicationDbContext context) => this.Context = context;

    public ApplicationDbContext Context { get; }

    public IActionResult Index()
    {
        var events = Context.Event.ToList();
        return View(events);
    }

    [HttpGet]
    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Create(EventDto eventDto)
    {
        // Ideally validate and save event here
        return View();
    }
}
