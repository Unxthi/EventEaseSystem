﻿using EventEasy.Models;
using EventEasy.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace EventEasy.Controllers
{
    public class BookingController : Controller
    {
        private readonly ApplicationDbContext context;
        public BookingController(ApplicationDbContext context) => this.context = context;
        public IActionResult Index()
        {
            var Booking = context.Bookings.ToList();
            return View(Booking);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(BookingDto bookingDto)
        {
            if (bookingDto.EventName == null)
            {
                ModelState.AddModelError("BookingId", "BookingId is required");
            }

            if(!ModelState.IsValid)
            {
                return View(bookingDto);
            }
            return RedirectToAction("Index","bookingDto");
        }
        public IActionResult Edit(int id)
        {
            var booking = context.Bookings.Find(id);
            if (booking == null)
            {
                return NotFound();
            }
            return View(booking);
        }


    }
}

