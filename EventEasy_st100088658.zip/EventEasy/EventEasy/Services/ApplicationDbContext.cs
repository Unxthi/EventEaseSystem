﻿using EventEasy.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
    

namespace EventEasy.Services
{
    public class ApplicationDbContext(DbContextOptions options) : DbContext(options)   
    {
        private DbSet<Event> @event;
        private DbSet<Boooking> bookings;

        public DbSet<Venue> Venue { get; set; }
        public DbSet<Event> Event { get => @event; set => @event = value; }

        public DbSet<Boooking> Bookings { get => bookings; set => bookings = value; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Boooking>()
                .HasKey(b => b.BookingId);  // Define 'Id' as the primary key, or use any other unique property
        }

    }
}
