﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace EventEasy.Models
{
    public class Boooking
    {
        public int BookingId { get; set; }


        [MaxLength(100)]
        public string EventId { get; set; } = "";
        [MaxLength(100)]
        public string EventName { get; set; } = "";

        [MaxLength(100)]
        public string EventType { get; set; } = "";
        [MaxLength(100)]
        public string VenueId { get; set; } = "";

        public DateTime BookingDate { get; set; }

        public Boooking(DateTime bookingDate) => BookingDate = bookingDate;

        [Precision(38, 8)]
        public decimal BookingPrice { get; set; }

    }
}
