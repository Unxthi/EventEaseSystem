﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace EventEasy.Models
{
    public class Event
    {

        public string Id { get; set; } = "";
        [MaxLength(100)]
        public string EventName { get; set; } = "";
        [MaxLength(100)]
        public string EventDescription { get; set; } = "";
        [MaxLength(100)]

        public DateTime EventDate { get; set; }

        [MaxLength(100)]
        public string VenueId { get; set; } = "";

        [Precision(38,8)]
        public decimal VenuePrice { get; set; }
    }
}
