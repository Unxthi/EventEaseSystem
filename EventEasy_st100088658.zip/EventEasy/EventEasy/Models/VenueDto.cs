﻿using System.ComponentModel.DataAnnotations;

namespace EventEasy.Models
{
    public class VenueDto
    {
        [Required,MaxLength(100)]
        public string Name { get; set; } = "";

        [Required, MaxLength(100)]
        public string Capacity { get; set; } = "";


        [Required, MaxLength(100)]
        public string location { get; set; } = "";

        [Required]
        public decimal Price { get; set; }

        public IFormFile? ImageFile { get; set; }

    }
}