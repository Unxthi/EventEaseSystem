﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace EventEasy.Models
{
    public class EventDto
    {
        public string EventName { get; set; } = "";
        [Required,MaxLength(100)]
        public string EventDescription { get; set; } = "";
        [Required,MaxLength(100)]

        public DateTime EventDate { get; set; }

        [Required, MaxLength(100)]
        public string VenueId { get; set; } = "";

        [Required]
        public decimal VenuePrice { get; set; }
    }
}
