﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace EventEasy.Models
{
    public class Venue
    {
        public int Id { get; set; }
        [MaxLength(100)]
        public string Name { get; set; } = "";

        [MaxLength(100)]

        public string Capacity { get; set; } = "";
        [MaxLength(100)]


        public string location { get; set; } = "";
        [Precision(38,6)]


        public decimal Price { get; set; }

        public string ImageFileName { get; set; } = "";

    }
}
