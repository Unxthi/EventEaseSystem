﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace EventEasy.Models
{
    public class BookingDto
    {
        [Required,]
        public int BookingId { get; set; }


        [Required, MaxLength(100)]
        public string EventId { get; set; } = "";
        [Required, MaxLength(100)]
        public string EventName { get; set; } = "";

        [Required, MaxLength(100)]
        public string EventType { get; set; } = "";
        [Required, MaxLength(100)]
        public string VenueId { get; set; } = "";

        [Precision(38, 8)]
        public decimal BookingPrice { get; set; }

        public DateTime BookingDate { get; set; }
    }
}
