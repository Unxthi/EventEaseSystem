using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace webpagewithvenue.Pages
{
    public class BookingModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
