using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace webpagewithvenue.Pages
{
    public class EventModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
